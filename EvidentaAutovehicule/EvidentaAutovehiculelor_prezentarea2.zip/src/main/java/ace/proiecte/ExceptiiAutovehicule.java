package ace.proiecte;

public class ExceptiiAutovehicule extends Exception {
    public ExceptiiAutovehicule(String mesaj) {
        super(mesaj);
    }
}
