package ace.proiecte;

public class ServiciiAutovehicul {
    public static void schimbaProprietar(Autovehicul auto, Proprietar nouProprietar) {
        // de implementat functia  pentru a schimba proprietarul autovehiculului
        System.out.println("Proprietarul autovehiculului " + auto + " a fost schimbat cu: " + nouProprietar);
    }
    // de implementat functia pentru a actualiza revizia in caz eronat
}
